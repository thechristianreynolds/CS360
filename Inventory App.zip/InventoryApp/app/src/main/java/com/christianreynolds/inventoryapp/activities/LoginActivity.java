package com.christianreynolds.inventoryapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;

import com.christianreynolds.inventoryapp.R;
import com.christianreynolds.inventoryapp.database.InventoryDatabase;
import com.christianreynolds.inventoryapp.fragments.FailedLoginRegisterDialogFragment;
import com.christianreynolds.inventoryapp.models.User;

public class LoginActivity extends FragmentActivity
                           implements FailedLoginRegisterDialogFragment.FailedLoginListener {

    // declare EditTexts
    private EditText mEmail;
    private EditText mPass;

    // declare database
    private InventoryDatabase inventoryDatabase;
    private User mUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // singleton database instance
        inventoryDatabase = InventoryDatabase.getInstance(getApplicationContext());

        // set value of EditTexts to EditTexts in activity_login.xml
        mEmail = findViewById(R.id.email);
        mPass = findViewById(R.id.pass);

        // set value of Buttons to Buttons in activity_login.xml
        // declare buttons
        Button mLoginButton = findViewById(R.id.login_button);
        Button mRegisterButton = findViewById(R.id.register_button);

        // set onClick function for login button
        mLoginButton.setOnClickListener(view -> {
            // clear all EditText errors
            mEmail.setError(null);
            mPass.setError(null);
            // if form is valid try and get user from db
            if (validateForm()) {
                User dbUser = inventoryDatabase.getUser(mUser.getEmail());
                // if user is found and password matches then login
                // if user is found and password does not match then show error
                if (dbUser != null) {
                    if (dbUser.getPass().equals(mUser.getPass())) {
                        Toast.makeText(LoginActivity.this, R.string.login_success, Toast.LENGTH_SHORT).show();
                        showItems();
                    } else {
                        mPass.setError(getString(R.string.incorrect_pass));
                    }
                } else { // otherwise ask user if they want to register the new email address

                    showFailedLoginRegisterDialog();
                }
            }
        });

        // set onClick function for register button
        mRegisterButton.setOnClickListener(view -> {
            // clear all EditText errors
            mEmail.setError(null);
            mPass.setError(null);
            // if form is valid try and get user from db
            if (validateForm()) {
                User dbUser = inventoryDatabase.getUser(mUser.getEmail());
                // if user is found alert user that email is already in use
                if (dbUser != null) {
                    mEmail.setError(getString(R.string.email_in_use));
                } else { // otherwise register the user
                    // clear all EditText errors
                    mEmail.setError(null);
                    mPass.setError(null);
                    if (inventoryDatabase.addUser(mUser)) {
                        Toast.makeText(LoginActivity.this, R.string.success_new_register, Toast.LENGTH_SHORT).show();
                        showItems();
                    } else {
                        Toast.makeText(LoginActivity.this, R.string.db_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    // checks if field is empty
    private boolean isEmpty(EditText editText) {
        CharSequence text = editText.getText().toString().trim();
        // if text is empty return true else false
        return TextUtils.isEmpty(text);
    }

    // checks if email is in valid format
    private boolean isEmail(EditText editText) {
        CharSequence email = editText.getText().toString();
        // if email is not empty and is in valid format return true else false
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }

    // validate email and password
    private boolean validateForm() {
        boolean isValid = true;
        if (isEmpty(mEmail)) {
            mEmail.setError(getString(R.string.email_blank_warn));
            isValid = false;
        } else if (!isEmail(mEmail)) {
            mEmail.setError(getString(R.string.email_not_valid_warn));
            isValid = false;
        }

        if (isEmpty(mPass)) {
            mPass.setError(getString(R.string.pass_blank_warn));
            isValid = false;
        } else if (mPass.getText().toString().trim().length() < 6) {
            mPass.setError(getString(R.string.pass_length_warn));
            isValid = false;
        }

        // if form is valid create new user instance
        if (isValid) {
            mUser = new User(mEmail.getText().toString(), mPass.getText().toString());
        }

        return isValid;
    }

    // open new activity passing it the user email for database queries
    public void showItems() {
        Intent intent = new Intent(LoginActivity.this, DatabaseViewActivity.class);
        intent.putExtra("email", mUser.getEmail());
        startActivity(intent);
        finish();
    }

    public void showFailedLoginRegisterDialog() {
        DialogFragment dialog = new FailedLoginRegisterDialogFragment();
        dialog.setCancelable(false);
        dialog.show(getSupportFragmentManager(), "FailedLoginRegisterDialogFragment");
    }

    // on positive click, register the entered user details as a new user
    @Override
    public void onDialogPositiveClick(DialogFragment dialog) {
        if (inventoryDatabase.addUser(mUser)) {
            Toast.makeText(this, R.string.success_new_register, Toast.LENGTH_SHORT).show();
            showItems();
        } else {
            Toast.makeText(this, R.string.db_error, Toast.LENGTH_SHORT).show();
        }
    }

    // negative click, alert the user that the credentials are incorrect
    @Override
    public void onDialogNegativeClick(DialogFragment dialog) {
        Toast.makeText(this, R.string.invalid_credentials, Toast.LENGTH_SHORT).show();
    }
}