package com.christianreynolds.inventoryapp.fragments;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.christianreynolds.inventoryapp.R;
import com.christianreynolds.inventoryapp.models.Item;

public class RequestNotificationPermissionDialogFragment extends DialogFragment {

    private Item mItem;

    public RequestNotificationPermissionDialogFragment(Item item) {
        mItem = item;
    }

    // return event's back to the host activity
    public interface RequestNotificationListener {
        void onDialogPositiveClick(DialogFragment dialog, Item item);
        void onDialogNegativeClick(DialogFragment dialog);
    }

    // use this instance of the interface to deliver action events
    RequestNotificationListener listener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        // make sure host activity implements callback interface
        try {
            listener = (RequestNotificationListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " must implement RequestNotificationListener");
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setMessage("Give this app permission to send low inventory notifications?");

        builder.setTitle("Enable Notifications");

        builder.setPositiveButton(R.string.enable_notifications, (dialog, id) -> listener.onDialogPositiveClick(RequestNotificationPermissionDialogFragment.this, mItem));

        builder.setNegativeButton(R.string.decline_notifications, (dialog, id) -> listener.onDialogNegativeClick(RequestNotificationPermissionDialogFragment.this));

        return builder.create();
    }

}
