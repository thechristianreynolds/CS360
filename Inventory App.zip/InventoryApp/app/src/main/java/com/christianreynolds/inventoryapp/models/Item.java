package com.christianreynolds.inventoryapp.models;

// this class represents items
public class Item {
    private long mId;
    private String mName;
    private int mQuantity;
    private String mUser;

    public Item() {}

    public Item(String name, int quantity, String user) {
        mName = name;
        mQuantity = quantity;
        mUser = user;
    }

    // return item name
    public String getName() {
        return mName;
    }

    // set item name
    public void setName(String name) {
        mName = name;
    }

    // return quantity
    public int getQuantity() {
        return mQuantity;
    }

    // set quantity
    public void setQuantity(int quantity) {
        mQuantity = quantity;
    }

    // return user of item
    public String getUser() {
        return mUser;
    }

    // set user
    public void setUser(String user) {
        mUser = user;
    }

    // get id
    public long getId() {
        return mId;
    }

    // set id
    public void setId(int id) {
        mId = id;
    }
}
