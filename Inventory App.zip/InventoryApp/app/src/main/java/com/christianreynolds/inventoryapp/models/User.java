package com.christianreynolds.inventoryapp.models;

// this class represents users
public class User {
    private String mEmail;
    private String mPass;

    public User() {}

    public User(String email, String pass) {
        mEmail = email;
        mPass = pass;
    }

    // return user's email
    public String getEmail() {
        return mEmail;
    }

    // set user's email
    public void setEmail(String email) {
        mEmail = email;
    }

    // return user's pass
    public String getPass() {
        return mPass;
    }

    // set user's pass
    public void setPass(String pass) {
        mPass = pass;
    }
}
