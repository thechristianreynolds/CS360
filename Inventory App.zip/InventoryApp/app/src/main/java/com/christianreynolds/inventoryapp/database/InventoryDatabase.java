package com.christianreynolds.inventoryapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import com.christianreynolds.inventoryapp.models.User;
import com.christianreynolds.inventoryapp.models.Item;

import java.util.ArrayList;
import java.util.List;

// singleton class
public class InventoryDatabase extends SQLiteOpenHelper {

    // what the database file will be named in internal storage
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    // only instance of InventoryDatabase
    private static InventoryDatabase inventoryDatabase;

    // get InventoryDatabase if exists else create new instance
    public static InventoryDatabase getInstance(Context context) {
        if (inventoryDatabase == null) {
            inventoryDatabase = new InventoryDatabase(context);
        }
        return inventoryDatabase;
    }

    // constructor
    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // user table
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_EMAIL = "email";
        private static final String COL_PASS = "pass";
    }

    // item table
    private static final class ItemTable {
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_QUANTITY = "quantity";
        private static final String COL_USER = "user";
    }

    // creates the UserTable in SQL defined in class UserTable
    // creates the ItemTable in SQL defined in class ItemTable
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
            UserTable.COL_EMAIL + " primary key, " +
            UserTable.COL_PASS + ")");

        db.execSQL("create table " + ItemTable.TABLE + " (" +
                ItemTable.COL_ID + " integer primary key autoincrement, " +
                ItemTable.COL_NAME + ", " +
                ItemTable.COL_QUANTITY + " int, " +
                ItemTable.COL_USER + ", " +
                "foreign key(" + ItemTable.COL_USER + ") references " +
                UserTable.TABLE + "(" + UserTable.COL_EMAIL + ") on delete cascade)");

        // the commented code is for testing purposes only

//        // add test users
//        String[] users = { "test1@test.com", "test2@test.com", "test3@test.com" };
//        for (int i = 0; i < users.length; i++) {
//            User user = new User(users[i], "testing" + (i + 1));
//            ContentValues values = new ContentValues();
//            values.put(UserTable.COL_EMAIL, user.getEmail());
//            values.put(UserTable.COL_PASS, user.getPass());
//            db.insert(UserTable.TABLE, null, values);
//        }
//
//        // add test items
//        for (int i = 0; i < 20; i++) {
//            Item item = new Item("item " + i, i + 2, users[0]);
//            ContentValues values = new ContentValues();
//            values.put(ItemTable.COL_NAME, item.getName());
//            values.put(ItemTable.COL_QUANTITY, item.getQuantity());
//            values.put(ItemTable.COL_USER, item.getUser());
//            db.insert(ItemTable.TABLE, null, values);
//        }
    }

    // drops user table on upgrade and creates a new one
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            } else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }

    // add new user return true if successful (id generated), return false if not
    public boolean addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_EMAIL, user.getEmail());
        values.put(UserTable.COL_PASS, user.getPass());
        long id = db.insert(UserTable.TABLE, null, values);
        return id != -1;
    }

    // return user if email found in db
    public User getUser(String email) {
        User user = null;

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + UserTable.TABLE +
                     " where " + UserTable.COL_EMAIL + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { email });

        if (cursor.moveToFirst()) {
            user = new User();
            user.setEmail(cursor.getString(0));
            user.setPass(cursor.getString(1));
        }

        cursor.close();

        return user;
    }

    // add item
    public long addItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, item.getName());
        values.put(ItemTable.COL_QUANTITY, item.getQuantity());
        values.put(ItemTable.COL_USER, item.getUser());
        return db.insert(ItemTable.TABLE, null, values);
    }

    // get item by id
    public Item getItem(long id) {
        Item item = null;

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + ItemTable.TABLE +
                " where " + ItemTable.COL_ID + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {Float.toString(id)});

        if (cursor.moveToFirst()) {
            item = new Item();
            item.setId(cursor.getInt(0));
            item.setName(cursor.getString(1));
            item.setQuantity(cursor.getInt(2));
            item.setUser(cursor.getString(3));
        }

        cursor.close();
        return item;
    }

    // returns all items associated with given email
    public List<Item> getItems(String email) {
        List<Item> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + ItemTable.TABLE +
                " where " + ItemTable.COL_USER + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { email });
        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.setId(cursor.getInt(0));
                item.setName(cursor.getString(1));
                item.setQuantity(cursor.getInt(2));
                item.setUser(cursor.getString(3));
                items.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return items;
    }

    // updates a single item
    public void updateItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, item.getName());
        values.put(ItemTable.COL_QUANTITY, item.getQuantity());
        db.update(ItemTable.TABLE, values,
                ItemTable.COL_ID + " = ?", new String[] {String.valueOf(item.getId())});
    }

    // delete item
    public void deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(ItemTable.TABLE,
                ItemTable.COL_ID + " = ?", new String[] { Long.toString(id) });
    }
}
