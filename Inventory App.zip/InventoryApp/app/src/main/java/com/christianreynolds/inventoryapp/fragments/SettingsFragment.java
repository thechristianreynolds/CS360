package com.christianreynolds.inventoryapp.fragments;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;

import androidx.core.app.NotificationManagerCompat;

import com.christianreynolds.inventoryapp.R;

public class SettingsFragment extends PreferenceFragment implements SharedPreferences.OnSharedPreferenceChangeListener {

    public static String PREFERENCE_NOTIFY = "pref_notify";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // load preferences xml
        addPreferencesFromResource(R.xml.preferences);

        // access default shared prefs
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
    }

    // register on shared preference change listener
    @Override
    public void onResume() {
        super.onResume();
        getPreferenceManager().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }

    // unregister shared preference change listener
    @Override
    public void onPause() {
        getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
        super.onPause();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        if (key.equals(PREFERENCE_NOTIFY)) {
            // change notification permission
            boolean allow = sharedPreferences.getBoolean(key, false);
            if (allow) {
                // do nothing
            } else {
                // turn off notifications
                NotificationManagerCompat.from(getActivity()).cancelAll();
            }
        }
    }
}
