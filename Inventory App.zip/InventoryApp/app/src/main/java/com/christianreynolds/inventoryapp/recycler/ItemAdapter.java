package com.christianreynolds.inventoryapp.recycler;

import android.content.res.ColorStateList;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.christianreynolds.inventoryapp.R;
import com.christianreynolds.inventoryapp.database.InventoryDatabase;
import com.christianreynolds.inventoryapp.models.Item;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemHolder> {
    private List<Item> mItems;
    private int primaryColor;
    private int primaryVariantColor;
    public ItemAdapterListener onClickListener;
    // declare database
    private InventoryDatabase mInventoryDatabase;

    // public constructor
    public ItemAdapter(List<Item> items, ItemAdapterListener listener, InventoryDatabase inventoryDatabase) {
        mItems = items;
        onClickListener = listener;
        mInventoryDatabase = inventoryDatabase;
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // get references to primary and primaryVariant colors for themeing
        TypedValue primaryValue = new TypedValue();
        TypedValue primaryVariantValue = new TypedValue();
        parent.getContext().getTheme().resolveAttribute(com.google.android.material.R.attr.colorPrimary, primaryValue, true);
        parent.getContext().getTheme().resolveAttribute(com.google.android.material.R.attr.colorPrimaryVariant, primaryVariantValue, true);
        primaryColor = primaryValue.data;
        primaryVariantColor = primaryVariantValue.data;

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        return new ItemHolder(layoutInflater, parent);
    }

    // update the recycler entry quantity by one
    public int plusItem(int position) {
        Item item = mItems.get(position);
        int qt = item.getQuantity();
        // if resulting quantity is 99 or less then update
        if (!(qt + 1 > 99)) {
            item.setQuantity(item.getQuantity() + 1);
            // update item in database
            mInventoryDatabase.updateItem(item);
            notifyDataSetChanged();
        }
        return qt;
    }

    // update the recycler view entry by minus one
    public int minusItem(int position) {
        Item item = mItems.get(position);
        // set quantity if not below zero else leave it at zero
        int qt = item.getQuantity();
        if (qt != 0) {
            item.setQuantity(item.getQuantity() - 1);
            mInventoryDatabase.updateItem(item);
        }
        notifyDataSetChanged();
        return qt;
    }

    public interface ItemAdapterListener {
        void addButtonOnClick(View v, int position);
        void removeButtonOnClick(View v, int position);
    }

    @Override
    public void onBindViewHolder(ItemHolder holder, int position) {
        holder.itemName.setText(mItems.get(position).getName());
        holder.itemQuantity.setText("" + mItems.get(position).getQuantity());

        // change row color based on position
        if (position % 2 == 0) {
            holder.entry.setBackground(AppCompatResources.getDrawable(holder.entry.getContext(), R.drawable.gradient_horizontal_reversed));
            holder.addButton.setBackgroundTintList(ColorStateList.valueOf(primaryVariantColor));
            holder.removeButton.setBackgroundTintList(ColorStateList.valueOf(primaryVariantColor));
        } else {
            holder.entry.setBackground(AppCompatResources.getDrawable(holder.entry.getContext(), R.drawable.gradient_horizontal));
//            holder.entry.setBackgroundColor(primaryVariantColor);
            holder.addButton.setBackgroundTintList(ColorStateList.valueOf(primaryColor));
            holder.removeButton.setBackgroundTintList(ColorStateList.valueOf(primaryColor));
        }
    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }

    public Item getItem(int position) {
        return mItems.get(position);
    }

    public void addItem(Item item) {
        mItems.add(item);
        // alert data change
        notifyDataSetChanged();
    }

    class ItemHolder extends RecyclerView.ViewHolder{
        TextView itemName;
        TextView itemQuantity;
        ImageButton removeButton;
        ImageButton addButton;
        ConstraintLayout entry;

        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.table_view, parent, false));
            itemName = itemView.findViewById(R.id.item_name);
            itemQuantity = itemView.findViewById(R.id.item_quantity);
            removeButton = itemView.findViewById(R.id.button_remove);
            addButton = itemView.findViewById(R.id.button_add);
            entry = itemView.findViewById(R.id.entry);

            addButton.setOnClickListener(v -> onClickListener.addButtonOnClick(v, getAdapterPosition()));

            removeButton.setOnClickListener(v -> onClickListener.removeButtonOnClick(v, getAdapterPosition()));
        }
    }
}
