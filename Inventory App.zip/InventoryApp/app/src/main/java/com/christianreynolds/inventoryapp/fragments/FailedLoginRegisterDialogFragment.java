package com.christianreynolds.inventoryapp.fragments;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.christianreynolds.inventoryapp.R;

public class FailedLoginRegisterDialogFragment extends DialogFragment {

    // return event's back to the host activity
    public interface FailedLoginListener {
        void onDialogPositiveClick(DialogFragment dialog);
        void onDialogNegativeClick(DialogFragment dialog);
    }

    // use this instance of the interface to deliver action events
    FailedLoginListener listener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        // make sure host activity implements callback interface
        try {
            listener = (FailedLoginListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " must implement FailedLoginListener");
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setMessage("You are trying to login with an unknown email. Would you like to register a new user instead?");

        builder.setTitle("Unknown email");

        builder.setPositiveButton(R.string.register_button, (dialog, id) -> listener.onDialogPositiveClick(FailedLoginRegisterDialogFragment.this));

        builder.setNegativeButton(R.string.cancel, (dialog, id) -> listener.onDialogNegativeClick(FailedLoginRegisterDialogFragment.this));

        return builder.create();
    }

}
