package com.christianreynolds.inventoryapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.christianreynolds.inventoryapp.R;
import com.christianreynolds.inventoryapp.database.InventoryDatabase;
import com.christianreynolds.inventoryapp.models.Item;

public class DatabaseNewEntryActivity extends AppCompatActivity {

    // declare database
    private InventoryDatabase inventoryDatabase;
    private Item mItem;

    // declare edit texts
    private EditText mItemName;
    private EditText mItemQuantity;

    private String mEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_new_entry);
        // get database instance
        inventoryDatabase = InventoryDatabase.getInstance(getApplicationContext());

        // get email from database view activity
        mEmail = getIntent().getStringExtra("email");

        // get edit texts and button
        mItemName = findViewById(R.id.item_name);
        mItemQuantity = findViewById(R.id.item_quantity);
        // declare button
        Button mAddItem = findViewById(R.id.add_button);

        mItem = new Item();

        // set onClick function for Add button
        mAddItem.setOnClickListener(view -> {
            // clear all EditText errors
            mItemName.setError(null);
            mItemQuantity.setError(null);
            // if form is valid try and add item to db
            if (validateForm()) {
                // add new item to db
                mItem.setName(mItemName.getText().toString().trim());
                mItem.setQuantity(Integer.parseInt(mItemQuantity.getText().toString()));
                mItem.setUser(mEmail);
                long itemId = inventoryDatabase.addItem(mItem);
                // send question id back
                Intent intent = getIntent();
                intent.putExtra("itemId", itemId);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }

    // checks if field is empty
    private boolean isEmpty(EditText editText) {
        CharSequence text = editText.getText().toString().trim();
        // if text is empty return true else false
        return TextUtils.isEmpty(text);
    }

    // validate email and password
    private boolean validateForm() {
        boolean isValid = true;
        if (isEmpty(mItemName)) {
            mItemName.setError(getString(R.string.item_name_blank_warn));
            isValid = false;
        }

        if (isEmpty(mItemQuantity)) {
            mItemQuantity.setError(getString(R.string.item_quantity_blank_warn));
            isValid = false;
        }
        if (mItemQuantity.getText().toString().trim().equals("0")) {
            mItemQuantity.setError(getString(R.string.item_quantity_zero_warn));
            isValid = false;
        }
        if (Integer.parseInt(mItemQuantity.getText().toString()) > 99) {
            mItemQuantity.setError(getString(R.string.item_quantity_too_large));
            isValid = false;
        }

        // if form is valid create new item instance
        if (isValid) {
            mItem = new Item(mItemName.getText().toString().trim(), Integer.parseInt(mItemQuantity.getText().toString().trim()), mEmail);
        }

        return isValid;
    }
}