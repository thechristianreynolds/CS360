package com.christianreynolds.inventoryapp.activities;

import android.animation.Animator;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.christianreynolds.inventoryapp.R;
import com.christianreynolds.inventoryapp.database.InventoryDatabase;
import com.christianreynolds.inventoryapp.fragments.RequestNotificationPermissionDialogFragment;
import com.christianreynolds.inventoryapp.fragments.SettingsFragment;
import com.christianreynolds.inventoryapp.models.Item;
import com.christianreynolds.inventoryapp.recycler.ItemAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class DatabaseViewActivity extends AppCompatActivity implements RequestNotificationPermissionDialogFragment.RequestNotificationListener {

    // variables for notifications
    private static final String CHANNEL_ID = "low_stock";
    private boolean mAllowNotify;
    private SharedPreferences mSharedPreferences;
    // this will be used to access shared preferences not set by the settings activity
    private SharedPreferences nSharedPreferences;

    private final int REQUEST_CODE_NEW_ITEM = 0;

    private InventoryDatabase inventoryDatabase;
    private RecyclerView mRecyclerView;
    private String mEmail;
    private ItemAdapter itemAdapter;
    private List<Item> mItems;

    // variables for floating action menu
    private FloatingActionButton menu;
    private LinearLayout addItem;
    private LinearLayout settings;

    private boolean isMenuOpen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // get notification setting from shared preferences
        nSharedPreferences = getSharedPreferences("com.christianreynolds.inventoryapp", MODE_PRIVATE);
        mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        mAllowNotify = mSharedPreferences.getBoolean(SettingsFragment.PREFERENCE_NOTIFY, false);

        // if false turn off notifications
        if (!mAllowNotify) {
            NotificationManagerCompat.from(this).cancelAll();
        }

        super.onCreate(savedInstanceState);
        createNotificationChannel();
        setContentView(R.layout.activity_database_view);
        mEmail = getIntent().getStringExtra("email");

        // get menu button and its sub items

        menu = findViewById(R.id.expand_menu);
        addItem = findViewById(R.id.addItem_fab_layout);
        settings = findViewById(R.id.settings_fab_layout);

        // singleton database
        inventoryDatabase = InventoryDatabase.getInstance(getApplicationContext());

        mItems = loadItems(mEmail);

        // recycler view
        mRecyclerView = findViewById(R.id.itemRecyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // set on click listeners for add and remove buttons in each row
        mRecyclerView.setAdapter(itemAdapter = new ItemAdapter(mItems, new ItemAdapter.ItemAdapterListener() {
            @Override
            public void addButtonOnClick(View v, int position) {
                int qt = itemAdapter.plusItem(position);
                if (qt + 1 == 100) {
                    Toast.makeText(DatabaseViewActivity.this, "Max quantity is 99", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void removeButtonOnClick(View v, int position) {
                Item selectedItem = itemAdapter.getItem(position);
                int qt = itemAdapter.minusItem(position);
                // show out of stock notification if qt is 1
                // if qt is 1 then the onClick being called will make it 0
                // effectively this is if qt is going to be zero then notify
                if (qt == 1) {
                    // if notifications are allowed then create one
                    if (mAllowNotify) {
                        showNotification(selectedItem);
                    } else if (nSharedPreferences.getBoolean("first_run", true)) { // if its first run prompt for notification permission
                        showRequestNotificationPermissionDialog(selectedItem);
                        nSharedPreferences.edit().putBoolean("first_run", false).commit();
                    }
                }
            }
        }, inventoryDatabase));

        // swipe to delete functionality
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            private boolean isDeleted;
            private Item deletedItem;

            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                // this is not being used, but it is necessary for ItemTouchHelper
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                // keep track of if item is deleted or not
                isDeleted = true;

                // get item at swiped position
                deletedItem = mItems.get(viewHolder.getAdapterPosition());

                int position = viewHolder.getAdapterPosition();

                // remove item from list
                mItems.remove(viewHolder.getAdapterPosition());

                // alert adapter that item has been removed
                itemAdapter.notifyItemRemoved(viewHolder.getAdapterPosition());

                // display undo snack-bar
                Snackbar.make(mRecyclerView, "DELETED: " + deletedItem.getName(), Snackbar.LENGTH_LONG).setAction("UNDO", v -> {
                    isDeleted = false;
                    // adding on click listener to Undo of snack-bar
                    // if clicked add deletedItem back to list
                    mItems.add(position, deletedItem);
                    // alert adapter that item has been added
                    itemAdapter.notifyItemInserted(position);
                }).show();

                // wait the duration of Snackbar.LENGTH_LONG before running
                new android.os.Handler(Looper.getMainLooper()).postDelayed(
                        () -> {
                            // actually delete from database if undo is not pressed after swiping
                            if (isDeleted) {
                                inventoryDatabase.deleteItem(deletedItem.getId());
                            }
                        }, 2750);
            }
            // attach to recyclerview
        }).attachToRecyclerView(mRecyclerView);

        // on click listener for outside of the fab menu
    }

    @Override
    protected void onResume() {
        super.onResume();

        // set mAllowNotify if user presses back from settings screen
        mAllowNotify = mSharedPreferences.getBoolean(SettingsFragment.PREFERENCE_NOTIFY, false);
        // if false turn off notifications
        if (!mAllowNotify) {
            NotificationManagerCompat.from(this).cancelAll();
        }
    }

    // get all items belonging to user with email
    private List<Item> loadItems(String email) {
        return inventoryDatabase.getItems(email);
    }

    // floating action button on click
    public void addItem(View view) {
        Intent intent = new Intent(DatabaseViewActivity.this, DatabaseNewEntryActivity.class);
        intent.putExtra("email", mEmail);
        startActivityForResult(intent, REQUEST_CODE_NEW_ITEM);
    }

    // float action menu on click
    public void checkMenu(View view) {
        if (!isMenuOpen) {
            showMenu();
        } else {
            closeMenu();
        }
    }

    // animations for floating action menu
    private void showMenu() {
        isMenuOpen = true;

        // show buttons
        addItem.setVisibility(View.VISIBLE);
        settings.setVisibility(View.VISIBLE);

        menu.animate().rotationBy(180);
        // move them above main floating action button
        addItem.animate().translationY(-getResources().getDimension(R.dimen.first_fab_animate));
        settings.animate().translationY(-getResources().getDimension(R.dimen.second_fab_animate));
    }

    // move buttons back behind main fab
    private void closeMenu() {
        isMenuOpen = false;

        menu.animate().rotation(0);

        addItem.animate().translationY(0);
        settings.animate().translationY(0);

        // make sure animation is completed before actually hiding floating action buttons
        settings.animate().translationY(0).setListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {

            }

            @Override
            public void onAnimationEnd(Animator animator) {
                if (!isMenuOpen) {
                    addItem.setVisibility(View.GONE);
                    settings.setVisibility(View.GONE);
                }
            }

            @Override
            public void onAnimationCancel(Animator animator) {

            }

            @Override
            public void onAnimationRepeat(Animator animator) {

            }
        });
    }

    // override onBackPress to close fab menu if back is pressed
    @Override
    public void onBackPressed() {
        if (isMenuOpen) {
            closeMenu();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == REQUEST_CODE_NEW_ITEM) {
            long itemId = data.getLongExtra("itemId", -1);
            Log.e("received itemId", String.valueOf(itemId));
            Item item = inventoryDatabase.getItem(itemId);
            itemAdapter.addItem(item);
        }
    }

    // create a notification channel as soon as activity starts
    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because its not a thing on older versions
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    public void showNotification(Item item) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(DatabaseViewActivity.this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_baseline_error_24)
                .setContentTitle("Out of Stock")
                .setContentText(item.getName() + " is out of stock")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(DatabaseViewActivity.this);
        notificationManager.notify((int)item.getId(), builder.build());
    }

    public void openSettings(View view) {
        Intent intent = new Intent(DatabaseViewActivity.this, SettingsActivity.class);
        startActivity(intent);
    }

    public void showRequestNotificationPermissionDialog(Item item) {
        DialogFragment dialog = new RequestNotificationPermissionDialogFragment(item);
        dialog.setCancelable(false);
        dialog.show(getSupportFragmentManager(), "RequestNotificationPermissionDialogFragment");
    }

    // on positive click, register the entered user details as a new user
    @Override
    public void onDialogPositiveClick(DialogFragment dialog, Item item) {
        mSharedPreferences.edit().putBoolean(SettingsFragment.PREFERENCE_NOTIFY, true).commit();
        showNotification(item);
        Toast.makeText(this, getString(R.string.notification_dialog_positive), Toast.LENGTH_SHORT).show();
    }

    // negative click, alert the user that the credentials are incorrect
    @Override
    public void onDialogNegativeClick(DialogFragment dialog) {
        mSharedPreferences.edit().putBoolean(SettingsFragment.PREFERENCE_NOTIFY, false).commit();
        Toast.makeText(this, getString(R.string.notification_dialog_negative), Toast.LENGTH_SHORT).show();
    }
}